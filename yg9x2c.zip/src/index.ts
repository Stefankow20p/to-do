import "./style.css";
class Thing {
  index: number;
  text: string;
  done: boolean;
}
let list = [];

function refresh() {
  document.querySelector("div").innerHtml = "";
  list.forEach((Element) => {
    const main = document.createElement("section");
    const text = document.createElement("textarea");
    const done = document.createElement("button");
    const deleteThing = document.createElement("button");
    const editThing = document.createElement("button");

    text.value = Element.text;
    main.append(text);

    if (Element.done) {
      done.value = "Zrobione";
      done.classList.add("green-background");
    } else {
      done.value = "Nie Zrobione";
      done.classList.add("red-background");
    }
    main.append(done);

    deleteThing.value = "Usuń";
    main.append(deleteThing);

    editThing.value = "Edytuj";
    main.append(editThing);

    document.querySelector("div").append(main);
  });
}

function addThing() {
  const thing = new Thing();
  thing.text = document.querySelector("#add-text").value;
  thing.done = false;
  let index: number = 0;
  while (true) {
    let numberExists: boolean = false;
    list.forEach((Element) => {
      if (Element.index == index) {
        numberExists = true;
      }
    });
    if (numberExists) {
      index++;
    } else {
      thing.index = index;
      break;
    }
  }
  list.push(thing);
  refresh();
}
document.querySelector("#add").addEventListener("click", addThing);
