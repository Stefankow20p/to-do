import "./style.css";
class Thing {
  index: number;
  text: string;
  done: boolean;
  deleted: boolean;
}
let list = [];

function refresh() {
  document.querySelector("div").innerHTML = "";
  list.forEach((Element) => {
    if (!Element.deleted) {
      const main = document.createElement("section");
      const text = document.createElement("textarea");
      const done = document.createElement("button");
      const deleteThing = document.createElement("button");
      const editThing = document.createElement("button");

      text.value = Element.text;
      main.append(text);

      if (Element.done) {
        done.innerText = "Zrobione";
        done.classList.add("green-background");
      } else {
        done.innerText = "Nie Zrobione";
        done.classList.add("red-background");
      }
      done.id = Element.index + "-done-btn";
      done.addEventListener("click", setOrUnsetDone);
      main.append(done);

      deleteThing.innerText = "Usuń";
      deleteThing.id = Element.index + "-delete-btn";
      deleteThing.addEventListener("click", deleteThingi);
      main.append(deleteThing);

      editThing.innerText = "Edytuj";
      editThing.id = Element.index + "-edit-btn";
      editThing.addEventListener("click", editThinf);
      main.append(editThing);

      document.querySelector("div").append(main);
    }
  });
}

function addThing() {
  const thing = new Thing();
  thing.text = document.querySelector("#add-text").value;
  document.querySelector("#add-text").value = "";
  thing.done = false;
  thing.deleted = false;
  let index: number = 1;
  while (true) {
    let numberExists: boolean = false;
    list.forEach((Element) => {
      if (Element.index == index) {
        numberExists = true;
      }
    });
    if (numberExists) {
      index++;
    } else {
      thing.index = index;
      break;
    }
  }
  list.push(thing);
  localStorage.setItem("data", JSON.stringify(list));
  refresh();
}
document.querySelector("#add").addEventListener("click", addThing);

function setOrUnsetDone() {
  const index: number = parseInt(this.id);
  for (let i = 0; i < list.length; i++) {
    if (list[i].index == index) {
      list[i].done = !list[i].done;
    }
  }
  localStorage.setItem("data", JSON.stringify(list));
  refresh();
}

function editThinf() {
  const newValue: string = this.parentNode.querySelector("textarea").value;
  const index: number = parseInt(this.id);
  for (let i = 0; i < list.length; i++) {
    if (list[i].index == index) {
      list[i].text = newValue;
    }
  }
  localStorage.setItem("data", JSON.stringify(list));
  refresh();
}

function deleteThingi() {
  const index: number = parseInt(this.id);
  for (let i = 0; i < list.length; i++) {
    if (list[i].index == index) {
      list[i].deleted = !list[i].deleted;
      break;
    }
  }
  localStorage.setItem("data", JSON.stringify(list));
  refresh();
}

if (localStorage.getItem("data") !== null) {
  list = JSON.parse(localStorage.getItem("data"));
  console.log(list);
  refresh();
}
// zmienic usuwanie tak by zostawały, ale sie nie pokazywaly
// ostylowac
// grupowanie zrobione, niezrobione
